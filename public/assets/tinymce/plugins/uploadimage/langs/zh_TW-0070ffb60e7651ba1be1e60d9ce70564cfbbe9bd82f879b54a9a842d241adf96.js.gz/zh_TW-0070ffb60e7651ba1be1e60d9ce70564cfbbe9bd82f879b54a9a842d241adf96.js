tinyMCE.addI18n("zh-TW", {
  "Insert an image from your computer": "上傳圖片",
  "Insert image": "插入圖片",
  "Choose an image": "選擇圖片",
  "You must choose a file": "須選擇一張圖片",
  "Got a bad response from the server": "伺服器回傳錯誤",
  "Didn't get a response from the server": "伺服器沒有回應",
  "Insert": "插入",
  "Cancel": "取消",
  "Image description": "圖片敘述",
});
