tinyMCE.addI18n('ko_KR', {
    'Insert an image from your computer': '컴퓨터에서 이미지 추가',
    'Insert image': "이미지 추가",
    'Choose an image': "이미지 선택",
    'You must choose a file': "이미지를 선택해주세요.",
    'Got a bad response from the server': "서버로부터 오류",
    "Didn't get a response from the server": "서버에서 응답 없음.",
    'Insert': "추가",
    'Cancel': "취소",
    'Image description': "이미지 설명",
});
  
