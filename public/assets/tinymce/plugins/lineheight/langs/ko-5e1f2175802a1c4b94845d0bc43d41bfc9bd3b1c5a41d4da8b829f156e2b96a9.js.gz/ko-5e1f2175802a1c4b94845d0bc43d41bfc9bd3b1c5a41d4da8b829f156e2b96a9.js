tinymce.addI18n('ko', {
    "Line Height": "줄간격"
});
